# Mixed operational rehearsal diagnosis

Status: completed mixed observations, post-run database snapshot and raw decoder export inspected. The controller reports that the instrumentation builder rejected sampled Analytics Engine data, so no admissible instrumentation/report exists. The executed profile, workload, source identity, decoder digest, operation counts and acceptance criteria remain unchanged. No implementation, deployment, test rerun or extra live request was performed for this diagnosis.

The completed window is **2026-09-27T19:34:00.171Z–19:41:18.693Z**. The allowlisted observation fields confirm 96 previews: 88 successful and 8 failed; all 24 uploads passed with verified hashes, all 20 controls passed and all 11 probes passed, including both seeds. The controller's transport summary recorded 24 HTTP 503 responses. This is a failed observation under operational-v1's requirement that every declared operation succeed, even if regeneration later recovers. It does not yet identify a decoder failure.

The eight failed preview indexes are exactly **0, 1, 12, 13, 50, 51, 62, 63**, matching both seeds and all their visits. All have `previewHit: false` and `previewPrivate: false`; the latter follows the missing HTTP 200 and does not itself demonstrate a privacy leak. Their operation durations are 5.904, 5.947, 4.279, 4.644, 3.837, 3.425, 3.424 and 3.833 seconds, respectively. The source-based seed-selection hypothesis is confirmed.

The read-only aggregate in `postflight.json` matches exactly two seed rows: both originals `stored`, both previews `ready`, neither with a failure code, and both with `run_count: 1`. The database query observed them at **19:42:33.098Z**. Preview claims span **19:34:35.326Z–35.581Z**, and database-ready timestamps span **19:34:53.437Z–55.459Z**. These independent aggregate bounds imply each seed's claim-to-ready interval lies within **17.856–20.133 seconds**; they do not identify exact per-seed pairings. Both became ready inside the original run window. This supports the short GET retry policy exhausting before asynchronous readiness, rather than a persistent regeneration failure. The observations do not store per-request wall-clock starts, and no late GET or fresh R2 integrity check was performed.

The genuine raw `private/export.json` decoder rows report mixed `preview/preview` outcomes of **2 ok jobs** and **1 busy refusal**; the ok row reports **21,707 ms native time**, **400,773,120 bytes peak RSS**, **22,941,197 bytes peak scratch** and **41,899,814 source bytes**. Upload-lane rows report 25 ok jobs and 3 busy refusals. These four rows show `maxSampleInterval: 1`, but the complete export was rejected for sampled Analytics Engine data; these are **diagnostic rows, not an admitted qualification or resource report**. They are consistent with successful regeneration and bounded native busy recovery. A busy refusal is distinct from the 24 outward pending-preview HTTP 503 responses.

## Source trace

- Mixed prepares two regeneration seeds before concurrent uploads/previews, prepending each seed to the reused gallery (`scripts/mobile-image-load-harness.mjs:236-242`; `scripts/mobile-image-load-adapter.mjs:431-438`). Assuming exactly 24 published cold originals and both seed probes succeed, the 26-item gallery maps seed slots 0/1 to preview indexes **0, 1, 12, 13, 50, 51, 62, 63** (`mobile-image-load-harness.mjs:106-110`; adapter `370-373`). Matching all eight failed indexes would localize the failures to all seed visits without exposing media identifiers.
- A missing preview queues an asynchronous workflow and immediately returns `IMAGE_PREVIEW_UNAVAILABLE` HTTP 503. Pending reads also return 503; there is no original-image fallback (`worker/storage/previews.ts:102-136`). The unique active media/source/profile tuple coalesces concurrent misses (`worker/db/image-previews.ts:43-61`). Therefore an HTTP 503 here does not prove a native `busy` response.
- The operational adapter makes at most three preview GET attempts, with explicit waits of 350 ms and 700 ms; request latency is additional (`scripts/mobile-image-load-adapter.mjs:375-388`). This is much shorter than the workflow's retry schedule: two retries, initially after 30 seconds with exponential backoff, and an eight-minute step timeout (`worker/index.ts:36-39`). The private decoder client separately allows up to three fresh-source attempts, excludes previously selected instances, uses 25/50 ms retry waits and a 135-second per-attempt timeout (`worker/services/image-decoder.ts:10,83-86,115-183`). Preview and upload pools are distinct (`services/image-decoder/worker/index.ts:22-24`).
- The real guest gallery has **no automatic image retry or regeneration polling**. On an image error it shows "Preview unavailable" and a manual "Retry preview" button. Each click increments `?retry=N`, clears the failed state and preserves keyboard focus; there is no programmed click-count cap (`src/features/gallery/GuestGalleryPhoto.tsx:13-43`). Stored photos advertise `previewAvailable: true` (`worker/db/media.ts:544-565`). The gallery metadata hook has no timed refetch (`src/features/gallery/useGuestGallery.ts:25-56`). Thus a guest can retry after recovery, but the fallback persists for that mounted photo without interaction. This is source evidence, not browser/device proof.

## Minimal next diagnostic

1. Completed: read only the observation's window, preview `index`, `elapsedMs`, `ok`, `previewHit`, `previewPrivate`, upload/control success flags and probe `kind`/`ok` fields. The failed indexes match the eight above. No credentials or media identifiers were read.
2. Completed for decoder outcomes: inspect the already-planned export's mixed preview/preview decoder outcomes, job counts and native time. The controller/analytics reviewer owns the sampled-dataset rejection. Native success alone does not prove persistence or a later successful seed GET; the separate database snapshot supports readiness.
3. Retain the original failed observations. A timing mismatch, delayed recovery or persistence defect must be reported separately; none converts these operations into passes. Preserve the cached-preview two-second guardrail and all declared operation counts.

Current conclusion: exhausted preview GET retries are localized to the two asynchronously regenerated seeds. Both later reached database-ready on their first workflow run, and raw decoder rows report successful regeneration, supporting a harness retry-timing mismatch with regeneration readiness. The mixed operational result remains failed, and instrumentation admission is separately unresolved because of sampling. Database readiness does not prove a later successful guest image read. The actual guest UI requires a manual retry, so the temporary unavailable state also has a user-visible effect. No criterion, timing, operation count or recorded result was changed to obtain a pass.

## Optional read-only database snapshot after completion

The controller may execute this aggregate through the existing read-only D1 transport after the run. Bind the existing gallery event ID, `2026-09-27T19:34:00.171Z`, and `2026-09-27T19:41:18.693Z`. Do not print the bindings. The expected `matched_seed_count` is exactly 2; any other count makes this selection inconclusive.

The seed predicate follows the adapter's `seed-${runId}-${index}` idempotency key (`mobile-image-load-adapter.mjs:433`, passed unchanged at `231-234`). The media column is `idempotency_key` (`worker/db/media.ts:76`); the preview profile is `mobile-preview-v1` (`shared/image-decoder-contract.ts:6`). This query retrieves no identifiers, keys, filenames, hashes, credentials or object paths and cannot trigger regeneration.

```sql
WITH seeds AS (
  SELECT id, event_id, upload_state, created_at, stored_at
  FROM media
  WHERE event_id = ?1
    AND created_at >= ?2 AND created_at <= ?3
    AND idempotency_key LIKE 'seed-%'
    AND mime_type = 'image/jpeg'
    AND declared_byte_size BETWEEN 20000001 AND 20971520
), ranked_previews AS (
  SELECT p.media_id, p.state, p.failure_code, p.run_count,
         p.created_at, p.writer_settled_at, p.updated_at,
         ROW_NUMBER() OVER (
           PARTITION BY p.media_id ORDER BY p.generation DESC
         ) AS latest
  FROM media_image_previews p
  JOIN seeds s ON s.id = p.media_id AND s.event_id = p.event_id
  WHERE p.profile = 'mobile-preview-v1'
)
SELECT strftime('%Y-%m-%dT%H:%M:%fZ', 'now') AS observed_at,
       (SELECT COUNT(*) FROM seeds) AS matched_seed_count,
       s.upload_state,
       COALESCE(p.state, 'absent') AS preview_state,
       p.failure_code,
       COUNT(*) AS seed_count,
       MIN(p.run_count) AS min_run_count,
       MAX(p.run_count) AS max_run_count,
       MIN(s.stored_at) AS first_original_stored_at,
       MAX(s.stored_at) AS last_original_stored_at,
       MIN(p.created_at) AS first_preview_claimed_at,
       MAX(p.created_at) AS last_preview_claimed_at,
       MIN(CASE WHEN p.state = 'ready' THEN p.writer_settled_at END) AS first_database_ready_at,
       MAX(CASE WHEN p.state = 'ready' THEN p.writer_settled_at END) AS last_database_ready_at,
       MIN(p.updated_at) AS first_last_update_at,
       MAX(p.updated_at) AS last_last_update_at
FROM seeds s
LEFT JOIN ranked_previews p ON p.media_id = s.id AND p.latest = 1
GROUP BY s.upload_state, COALESCE(p.state, 'absent'), p.failure_code;
```

`ready` sets `writer_settled_at` in `markReady` (`worker/db/image-previews.ts:91-97`); `updated_at` can subsequently change during settlement/reconciliation and is not a completion timestamp. This is a post-run database snapshot, not a historical snapshot at `endedAt`; the media selection is window-bound, but a later workflow can finish afterward. A ready row supports persistence bookkeeping and permits comparison with the failed request period. It does not turn a failed observation into a pass, prove a later successful seed GET, or freshly verify R2 bytes.

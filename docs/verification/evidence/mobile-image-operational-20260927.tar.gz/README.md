# Preserved bounded operational attempt

This is the failed 2026-09-27 operational-v1 rehearsal, not a qualifying load report.
All 424 declared operations were recorded. Eight mixed preview operations failed.
The independent export was retrieved after the settlement interval, but its sampled
image-accounting rows caused the instrumentation builder to refuse it. No accepted
instrumentation or mobile-image-load report exists in this archive.

The evidence directory contains the exact hash-named observation bundle.
attempt-status.json contains computed observation summaries, explicit failure flags,
the bundle/export hashes and partial raw decoder diagnostics. The private subdirectory
contains only the allowlisted sanitized export, scope, generated query plan, identity
and version records. Its name does not imply that credential files were included.
postflight.json contains read-only aggregate database results and deployed version IDs.
diagnosis.md records the source-backed retry/readiness finding; review.md records the
independent evidence review.

Compare each included file with SHA256SUMS.json before use. The observation bundle's
filename is also its raw-byte SHA-256. Keep the original raw export unchanged. The
current instrumentation builder is expected to reject that export as sampled.

Credentials, event creation responses, completed authorizations, source-file paths,
fixture binaries, access links and bearer headers are excluded. Test event identifiers
in the scoped queries are retained so the exact measurements can be understood.

See docs/verification/mobile-image-operational-results-20260927.md in the accompanying
repository for scenario windows, current limitations and the next work. This archive
does not authorize a fresh run, deployment, admission change or event cleanup.

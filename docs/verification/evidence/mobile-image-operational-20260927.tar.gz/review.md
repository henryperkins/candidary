# Independent scoped live-rehearsal review

Status: scoped review complete. The failed attempt may be archived using the
allowlist below. This is not an operational qualification approval.

Reviewed the repository guidance, approved operational runbook, the three ignored
orchestration helpers (`prepare-live-run.mjs`, `run-one-live.mjs`,
`finish-live-run.mjs`), their calls into the reviewed harness/report/instrumentation
tooling, the three scoped authorizations, and the saved identity, versions and idle
preflight. No tests, network calls, credential-file reads or live mutations were
performed by the reviewer.

Initial review: no Critical or Important findings. The authorizations select
`operational-v1`, use the intended three distinct events, and match the approved
149/124/151 logical operations and media-payload ceilings. The orchestration pins
the four-script digest, delegates operations to the reviewed adapter, sanitizes
progress output, and obtains independent measurements through the actual exporter.
It does not substitute zero metrics or treat HTTP status alone as evidence.

## Final observations and independent export

All 424 declared operations are recorded. Cold has 149/149 successful operations;
warm has 124/124; mixed has 143/151. Across cold and mixed, all 48 main originals
have successful hash and receipt verification. All 60 direct controls and 28
probes succeeded, including both explicit multipart replays. Mixed preserves the
eight unsuccessful preview operations at indexes 0, 1, 12, 13, 50, 51, 62 and 63.
No recorded privacy, deletion, cancellation or original-hash violation was found.
Both upload scenarios reached four overlapping uploads.

Recorded windows are:

| Scenario | Start UTC | End UTC |
| --- | --- | --- |
| Cold | 2026-09-27T18:55:54.758Z | 2026-09-27T19:03:19.116Z |
| Warm | 2026-09-27T19:18:19.276Z | 2026-09-27T19:18:59.996Z |
| Mixed | 2026-09-27T19:34:00.171Z | 2026-09-27T19:41:18.693Z |

The gaps are 900.160 and 900.175 seconds, satisfying the fifteen-minute separation.
The actual deployment export at 19:46:21.904Z followed mixed completion by 303.211
seconds. Its queries, scope, windows and profile agree with the observations.
Postflight records unchanged main/decoder deployment versions at 100 percent.

The instrumentation builder correctly refused sampled Analytics Engine image
rows. Six groups have maximum sampling intervals of 2, 3 or 4. No accepted
instrumentation document or qualification report was produced. Sampled preview
counts cannot be treated as exact counts or silently replaced with observation
counts. The raw decoder export contains unsampled returned rows and is useful
diagnostically, but does not make the complete export admissible.

The database snapshot matches exactly two regeneration seeds, both ready after
one workflow run. Aggregate claim-to-ready bounds are 17.856 to 20.133 seconds;
the eight failed GET operations lasted approximately 3.4 to 5.9 seconds. Together
with the two successful preview-pool decoder jobs, this supports the timing
mismatch described in `diagnosis.md`. Per-request wall-clock start times were not
recorded, so this is a supported explanation rather than exact request-to-ready
pairing. Later database readiness does not convert the eight failures into passes
or prove a later successful image read.

`attempt-status.json` correctly distinguishes execution completion from success:
all-declared-operations-passed, instrumentation-accepted, qualification-report-
produced, operational-qualified, capacity-qualified and universal are all false.
Physical iOS/Android evidence remains unavailable.

## Integrity and portable archive clearance

Read-only `Get-FileHash -Algorithm SHA256` checks confirmed the exact observation
bundle hash `4234f7baee53e30a82f5da7e8837244430fb17609e81247104a374eb8f4e3c73`
and raw export hash `37e6ecdad9fab9779ce35aa5b05bca21adf2ee06f19d9dc84c646b6fc97bb208`.
The bundle has the expected fingerprint, immutable image reference and three
operational scenarios. Actual archive candidates were parsed/read and checked
against their producers; no bearer token, management/entry credential, cookie,
credential/source path or private-media URL was found. Aggregate API metadata was
also inspected. Scope/query records retain test event identifiers, which are not
access credentials.

Approved archive members:

- The single hash-named observation bundle under `evidence/`.
- `attempt-status.json`, `postflight.json`, `diagnosis.md` and this `review.md`.
- The exact `private/export.json`, `private/scope.json`,
  `private/export-plan.json`, `private/identity.json` and `private/versions.json`.
- A README limited to the failed-attempt explanation, artifact mapping and hashes.

Exclude authorization files, credentials, event-creation responses, the analytics
token, prepared-source catalogs and fixture binaries. Preserve export bytes
unchanged. No fabricated instrumentation or qualification report belongs in the
archive.

## Findings

No Critical or Important review defect remains in the orchestration or failed-
attempt preservation. Two material qualification blockers remain: the eight mixed
preview failures and the sampled image measurements. They are preserved and
reported, not remediated by this review. There are no additional Minor findings.

Reviewer validation was limited to source/artifact inspection, exact file hashes
and allowlist credential-content checks. No focused tests, repository-wide gates,
live requests, deployment or evidence regeneration was performed.

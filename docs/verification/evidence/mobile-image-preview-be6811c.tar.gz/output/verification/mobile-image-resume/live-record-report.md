# C24 live evidence record — 2026-09-26

Completed the records-only update after preview checkpoint `be6811c4beb9cb113ffb446deec9acebfe14759b`. No files are staged or newly committed.

- Verified the live report SHA-256 `f99ae2d2082638007282a2704132379291f348f78ca3bfe377551de59625900f`, its 39 unique case/fixture IDs, and every source SHA-256 against both the manifest and original bytes before using it. All results pass; runtime and cleanup failures are absent.
- Updated exactly 39 matched `evidence.live` pointers across 29 cases in `tests/fixtures/mobile-images/manifest.json`. Deep comparison to the C24 before snapshot differs only at those pointers; restoring them to null reproduces the exact before bytes. CRLF, all other fields, fixtures, hashes, release records and decoder pins are preserved.
- Before manifest SHA-256: `fb53f7e1eab6efd0df04c7f5d0e45ac180e9ed085057d98e71ec500874e854e7`; after: `d4593f9e54eb81b2aaaadf9bc51f364b67c383b20019686f3a1274b97933be05`. Machine-readable proof: `live-record-invariants.json`.
- Captured C24 after with `node scripts/capture-mobile-image-task.mjs --plan C --task C24 --phase after`. The allowlisted snapshot and manifest delta are under `../mobile-image-tasks/C/C24/after/`.
- Updated only the runbook current-status/resumption section to record completed step 8, the replacement deployment, recovered originals, read-only D1 cleanup/export observations, build/PWA results, the new comparison base and remaining limits. Historical sequence details remain. The complete documentation diff is `live-record-doc-delta.patch`; C24 snapshots cover only the manifest by design.

Focused check (run once):

```sh
node scripts/verify-mobile-image-corpus.mjs --check-manifest > output/verification/mobile-image-resume/corpus-after-live.json
```

Exit 0. `structureValid: true`, zero structural issues; live lane passes 39/39 fixtures across 29/32 cases. `complete: false`; local qualification remains empty in this recovery checkout. All 39 local pointers report missing historical evidence files, and independent reference files remain an inherited recovery gap. Android and iOS evidence are missing for all 39 fixtures; physical-device and load runs were not performed. The three fixtureless cases are `heic-sequence`, `live-photo-camera`, `live-photo-library`. Universal compatibility remains unverified.

Only tracked changes: `tests/fixtures/mobile-images/manifest.json` and `docs/verification/mobile-image-preview-release.md`. This task ran no unit reruns, repository gates, staging, commits, deployment or push. Independent review is pending.

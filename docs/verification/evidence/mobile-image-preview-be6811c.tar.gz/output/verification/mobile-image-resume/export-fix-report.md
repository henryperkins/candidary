# Complete ZIP export request amplification fix

Status: focused code fix and local regression checks complete; live preview export still needs a new run after deployment.

## Root cause

`processExport` passed a 1 MiB bounded read size to `ownedSourceStream` for Album jobs but passed `0` for complete jobs. With 16 KiB R2 transport fragments, the complete path called `assertOwnedRunActive` on both sides of every fragment. Since that check queries D1, a large original amplified Workflow subrequests until the live `prepare private event export-1` step hit `Too many API requests by single Worker invocation.` The RED fixture reproduced 591 ownership checks for more than 280 pulls across two 2,334,146-byte originals.

## Change

Complete and Album sources now share the established 1 MiB bounded read size. The existing `ownedSourceStream` checks ownership and event deletion before and after each bounded read, including EOF. Selection-v1 still uses per-fragment checks and unchanged expiry handling. Streaming, cancellation, backpressure, source bytes, ZIP names, and archive content generation were not changed.

Added complete-export regressions using the existing fragmented R2 helper. They check Ready ZIP membership and original SHA-256 hashes, cap ownership checks independently of transport-fragment count, and exercise deletion during the first bounded read and at EOF. Both deletion cases require Failed rather than Ready, empty part inventory, and no objects under the attempt prefix.

Changed files: `worker/workflows/export.ts`, `tests/worker/album-export-performance.test.ts`.

## Verification

- RED: `npm run test:worker -- tests/worker/album-export-performance.test.ts -t 'prepares a complete ZIP|stops a complete export'` exited 1. The new complete ZIP case failed at `expected 591 to be less than or equal to 40`; both new deletion cases passed. Three existing cases were skipped by the name filter.
- GREEN: `npm run test:worker -- tests/worker/album-export-performance.test.ts tests/worker/export-workflow-ownership.test.ts tests/worker/photo-export-archive.test.ts` exited 0: 3 files, 20 tests passed.
- `git diff --check` exited 0.

Vitest emitted a local missing-secrets warning and workerd `pump canceled` messages during stream cancellation; the focused union still exited 0. No repository-wide gate, deployment, remote write, or live re-export was run. The preview Workflow subrequest result remains unverified until the fixed code is deployed and the complete export is retried.

# Complete-export request amplification review

**Verdict: approve.** Critical: 0; Important: 0; Minor: 1.

The change applies the existing 1 MiB bounded source-read batching to complete exports while leaving selection-v1 on per-fragment checks (`worker/workflows/export.ts:219-221`). `ownedSourceStream` checks ownership and event deletion before and after each batch, including EOF, and still cancels the source on error (`worker/workflows/export.ts:75-103`). The existing ZIP writer and multipart uploader retain streaming backpressure and cancellation. The owned Ready transaction also checks that the event is not deleted (`worker/db/exports.ts:989-1000`). No source-byte or archive-name generation changed.

The new complete-export cases cover fragmented originals, original SHA-256 values, a bounded ownership-check count, deletion during the first bounded read and at EOF, Failed state, empty parts, and no objects under the attempt prefix. I reused the implementer's focused GREEN result: `npm run test:worker -- tests/worker/album-export-performance.test.ts tests/worker/export-workflow-ownership.test.ts tests/worker/photo-export-archive.test.ts` — 20/20 passed. I did not rerun tests or repository gates. Live preview behavior remains unverified until deployment and a new complete export.

- **Minor — ZIP membership assertion is incomplete** (`tests/worker/album-export-performance.test.ts:131-139`). The complete-export test checks three entries and `media.csv`, then hashes whichever two entries appear first. It would pass if both photo entries had unexpected names. Assert the two expected `exportPath` names if exact ZIP membership needs direct regression coverage. This is a test coverage note; the patch does not change path generation.
